from flask import Flask, render_template, jsonify, request
import json
import os
from datetime import datetime

app = Flask(__name__)

# Configuration
app.config['SECRET_KEY'] = 'ton_secret_key_ici'
app.config['DATA_FOLDER'] = 'data'

# Assurer que le dossier data existe
os.makedirs(app.config['DATA_FOLDER'], exist_ok=True)

def load_data(filename):
    """Charger les données depuis un fichier JSON"""
    filepath = os.path.join(app.config['DATA_FOLDER'], filename)
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        return []

def save_data(data, filename):
    """Sauvegarder les données dans un fichier JSON"""
    filepath = os.path.join(app.config['DATA_FOLDER'], filename)
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

# Routes principales
@app.route('/')
def home():
    return render_template('members.html')

@app.route('/admin')
def admin():
    return render_template('admin.html')

# API Routes
@app.route('/api/stats')
def api_stats():
    """Endpoint pour les statistiques"""
    stock = load_data('stock.json')
    users = load_data('users.json')
    
    return jsonify({
        'status': 'success',
        'data': {
            'stock_count': len(stock),
            'users_count': len(users),
            'last_update': datetime.now().isoformat(),
            'bot_online': True
        }
    })

@app.route('/api/submit', methods=['POST'])
def api_submit():
    """Endpoint pour soumettre du contenu"""
    data = request.get_json()
    
    if not data or 'content' not in data:
        return jsonify({'status': 'error', 'message': 'Données manquantes'})
    
    content = data['content'].strip()
    if not content:
        return jsonify({'status': 'error', 'message': 'Contenu vide'})
    
    # Charger les soumissions en attente
    pending = load_data('pending.json')
    
    # Ajouter la nouvelle soumission
    new_submission = {
        'content': content,
        'timestamp': datetime.now().isoformat(),
        'status': 'pending'
    }
    
    pending.append(new_submission)
    save_data(pending, 'pending.json')
    
    return jsonify({
        'status': 'success', 
        'message': 'Contenu soumis avec succès!'
    })

@app.route('/api/admin/data', methods=['GET'])
def admin_data():
    """Endpoint pour les données admin"""
    stock = load_data('stock.json')
    users = load_data('users.json')
    pending = load_data('pending.json')
    
    return jsonify({
        'stock': stock[:50],  # Premier 50 éléments
        'users': users,
        'pending': pending,
        'stats': {
            'total_stock': len(stock),
            'total_users': len(users),
            'pending_approvals': len(pending)
        }
    })

@app.route('/api/admin/approve', methods=['POST'])
def admin_approve():
    """Approuver du contenu"""
    data = request.get_json()
    content = data.get('content')
    
    if not content:
        return jsonify({'status': 'error', 'message': 'Contenu manquant'})
    
    # Ajouter au stock
    stock = load_data('stock.json')
    stock.append(content)
    save_data(stock, 'stock.json')
    
    # Retirer des pending
    pending = load_data('pending.json')
    pending = [p for p in pending if p['content'] != content]
    save_data(pending, 'pending.json')
    
    return jsonify({'status': 'success', 'message': 'Contenu approuvé!'})

# Gestion des erreurs
@app.errorhandler(404)
def not_found(error):
    return jsonify({'status': 'error', 'message': 'Page non trouvée'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'status': 'error', 'message': 'Erreur interne du serveur'}), 500

if __name__ == '__main__':
    # Initialiser les fichiers de données s'ils n'existent pas
    for file in ['stock.json', 'users.json', 'pending.json']:
        if not os.path.exists(os.path.join(app.config['DATA_FOLDER'], file)):
            save_data([], file)
    
    print("🚀 Serveur Flask démarré!")
    print("📊 Site public: http://localhost:5000")
    print("🛠️ Dashboard admin: http://localhost:5000/admin")
    
    app.run(debug=True, host='0.0.0.0', port=5000)