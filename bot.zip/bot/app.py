from flask import Flask, render_template, jsonify, request
import json
import os
from datetime import datetime

app = Flask(__name__)

# Configuration
DATA_FOLDER = "data"

def load_data(filename):
    """Charger les données JSON"""
    filepath = os.path.join(DATA_FOLDER, filename)
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        return [] if filename != "users.json" else {}

def save_data(data, filename):
    """Sauvegarder les données JSON"""
    filepath = os.path.join(DATA_FOLDER, filename)
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

# Routes principales
@app.route('/')
def home():
    return render_template('members.html')

@app.route('/admin')
def admin():
    return render_template('admin.html')

# API Routes
@app.route('/api/stats')
def api_stats():
    stock = load_data('stock.json')
    users = load_data('users.json')
    settings = load_data('settings.json')
    
    return jsonify({
        'stock_count': len(stock),
        'users_count': len(users),
        'bot_online': settings.get('bot_online', True),
        'last_update': datetime.now().isoformat()
    })

@app.route('/api/submit', methods=['POST'])
def api_submit():
    data = request.get_json()
    content = data.get('content', '').strip()
    
    if not content:
        return jsonify({'success': False, 'error': 'Contenu vide'})
    
    # Ajouter aux soumissions en attente
    pending = load_data('pending.json')
    pending.append({
        'content': content,
        'timestamp': datetime.now().isoformat(),
        'status': 'pending'
    })
    save_data(pending, 'pending.json')
    
    return jsonify({'success': True, 'message': 'Contenu soumis !'})

@app.route('/api/admin/data')
def admin_data():
    stock = load_data('stock.json')
    users = load_data('users.json')
    pending = load_data('pending.json')
    
    return jsonify({
        'stock': stock[:20],  # Premier 20 éléments
        'users': users,
        'pending': pending,
        'stats': {
            'total_stock': len(stock),
            'total_users': len(users),
            'pending_count': len(pending)
        }
    })

@app.route('/api/admin/approve', methods=['POST'])
def approve_content():
    data = request.get_json()
    content = data.get('content')
    
    if not content:
        return jsonify({'success': False, 'error': 'Contenu manquant'})
    
    # Ajouter au stock
    stock = load_data('stock.json')
    if content not in stock:
        stock.append(content)
        save_data(stock, 'stock.json')
    
    # Retirer des pending
    pending = load_data('pending.json')
    pending = [p for p in pending if p['content'] != content]
    save_data(pending, 'pending.json')
    
    return jsonify({'success': True, 'message': 'Contenu approuvé !'})

if __name__ == '__main__':
    print("🚀 Serveur Flask démarré!")
    print("👉 http://localhost:5000")
    print("🔧 http://localhost:5000/admin")
    app.run(debug=True, host='0.0.0.0', port=5000)