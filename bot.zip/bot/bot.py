import discord
from discord.ext import commands, tasks
from discord import app_commands
import asyncio
import random
import os
import json
from datetime import datetime, timedelta
import aiohttp
from typing import Dict, List, Set

# Configuration
intents = discord.Intents.default()
intents.messages = True
intents.dm_messages = True
intents.message_content = True
intents.guilds = True

bot = commands.Bot(command_prefix='/', intents=intents)

# Fichiers de stockage
STOCK_FILE = "stock.json"
USER_GENERATED_FILE = "user_generated.json"
PENDING_APPROVAL_FILE = "pending_approval.json"
REFERRALS_FILE = "referrals.json"
ADMIN_SETTINGS_FILE = "admin_settings.json"

USER_COOLDOWNS = {}
RESTOCK_USER_ID = 1188938933489369093
COOLDOWN_SECONDS = 30

# Chargement des données
def load_data(filename, default=None):
    try:
        with open(filename, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return default if default is not None else {}

def save_data(data, filename):
    with open(filename, 'w') as f:
        json.dump(data, f, indent=2)

# Initialisation
for file, default in [
    (STOCK_FILE, []),
    (USER_GENERATED_FILE, {}),
    (PENDING_APPROVAL_FILE, []),
    (REFERRALS_FILE, {}),
    (ADMIN_SETTINGS_FILE, {"bot_online": True, "last_restock": None})
]:
    if not os.path.exists(file):
        save_data(default, file)

stock = load_data(STOCK_FILE, [])
USER_GENERATED = load_data(USER_GENERATED_FILE, {})
PENDING_APPROVAL = load_data(PENDING_APPROVAL_FILE, [])
REFERRALS = load_data(REFERRALS_FILE, {})
ADMIN_SETTINGS = load_data(ADMIN_SETTINGS_FILE, {})

# Système de validation
class ApprovalSystem:
    def __init__(self):
        self.pending_approvals = PENDING_APPROVAL
    
    async def send_approval_request(self, user: discord.User, content: str):
        """Envoyer une demande d'approbation à l'admin"""
        admin = await bot.fetch_user(RESTOCK_USER_ID)
        
        embed = discord.Embed(
            title="🔄 Demande d'Approval",
            description=f"Contenu soumis par {user.mention}",
            color=0xffa500,
            timestamp=datetime.now()
        )
        
        embed.add_field(name="📝 Contenu", value=content[:500] + ("..." if len(content) > 500 else ""), inline=False)
        embed.add_field(name="👤 Auteur", value=f"{user.name}#{user.discriminator}", inline=True)
        embed.add_field(name="🆔 User ID", value=user.id, inline=True)
        
        # Créer les boutons d'approbation
        view = ApprovalView(content, user.id)
        
        try:
            await admin.send(embed=embed, view=view)
            self.pending_approvals.append({
                "content": content,
                "user_id": user.id,
                "username": f"{user.name}#{user.discriminator}",
                "timestamp": datetime.now().isoformat()
            })
            save_data(self.pending_approvals, PENDING_APPROVAL_FILE)
            return True
        except Exception as e:
            print(f"Erreur envoi approval: {e}")
            return False
    
    def remove_approval(self, content: str):
        """Retirer une approbation en attente"""
        self.pending_approvals = [p for p in self.pending_approvals if p["content"] != content]
        save_data(self.pending_approvals, PENDING_APPROVAL_FILE)

# Vue pour les boutons d'approbation
class ApprovalView(discord.ui.View):
    def __init__(self, content: str, user_id: int):
        super().__init__(timeout=86400)  # 24 heures
        self.content = content
        self.user_id = user_id
    
    @discord.ui.button(label="✅ Approuver", style=discord.ButtonStyle.success)
    async def approve(self, interaction: discord.Interaction, button: discord.ui.Button):
        global stock
        stock.append(self.content)
        save_data(stock, STOCK_FILE)
        
        # Notifier l'utilisateur
        try:
            user = await bot.fetch_user(self.user_id)
            await user.send("🎉 Votre contenu a été approuvé et ajouté au stock!")
        except:
            pass
        
        # Mettre à jour les approbations en attente
        approval_system.remove_approval(self.content)
        
        await interaction.response.send_message("✅ Contenu approuvé et ajouté au stock!", ephemeral=True)
        
        # Mettre à jour le statut
        ADMIN_SETTINGS["last_restock"] = datetime.now().isoformat()
        save_data(ADMIN_SETTINGS, ADMIN_SETTINGS_FILE)
    
    @discord.ui.button(label="❌ Refuser", style=discord.ButtonStyle.danger)
    async def reject(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Notifier l'utilisateur
        try:
            user = await bot.fetch_user(self.user_id)
            await user.send("❌ Votre contenu n'a pas été approuvé pour le stock.")
        except:
            pass
        
        # Mettre à jour les approbations en attente
        approval_system.remove_approval(self.content)
        
        await interaction.response.send_message("❌ Contenu refusé.", ephemeral=True)

approval_system = ApprovalSystem()

@bot.event
async def on_ready():
    print(f'🎮 {bot.user} est connecté à Discord!')
    print(f'📊 Stock actuel: {len(stock)} éléments')
    print(f'👥 Utilisateurs enregistrés: {len(USER_GENERATED)}')
    print(f'⏳ Approbations en attente: {len(PENDING_APPROVAL)}')
    
    ADMIN_SETTINGS["bot_online"] = True
    save_data(ADMIN_SETTINGS, ADMIN_SETTINGS_FILE)
    
    try:
        synced = await bot.tree.sync()
        print(f'✅ Commandes slash synchronisées: {len(synced)}')
    except Exception as e:
        print(f'❌ Erreur synchronisation: {e}')

# COMMANDES MEMBRES
@bot.tree.command(name="gen", description="Générer du contenu aléatoire")
@app_commands.describe(nombre="Nombre d'éléments à générer (1-10)")
async def gen_slash(interaction: discord.Interaction, nombre: int = 1):
    if not ADMIN_SETTINGS.get("bot_online", True):
        await interaction.response.send_message("❌ Le bot est actuellement en maintenance.", ephemeral=True)
        return
    
    user_id = str(interaction.user.id)
    
    if nombre > 10 or nombre < 1:
        await interaction.response.send_message("❌ Nombre doit être entre 1 et 10!", ephemeral=True)
        return
    
    # Vérifier cooldown
    if user_id in USER_COOLDOWNS:
        time_left = USER_COOLDOWNS[user_id] - datetime.now()
        if time_left.total_seconds() > 0:
            await interaction.response.send_message(f"⏰ Attendez {int(time_left.total_seconds())}s!", ephemeral=True)
            return
    
    # Vérifier stock
    if user_id in USER_GENERATED:
        user_generated = USER_GENERATED[user_id]
        available = len(stock) - len(user_generated)
        if available <= 0:
            await interaction.response.send_message("📭 Plus de stock pour toi!", ephemeral=True)
            return
        if nombre > available:
            await interaction.response.send_message(f"⚠️ Il te reste {available} éléments!", ephemeral=True)
            return
    
    await interaction.response.send_message(f"🔄 Génération de {nombre} élément(s)...", ephemeral=True)
    
    generated = []
    for _ in range(nombre):
        if user_id in USER_GENERATED:
            available_items = [item for item in stock if item not in USER_GENERATED[user_id]]
        else:
            available_items = stock.copy()
            USER_GENERATED[user_id] = []
        
        if not available_items:
            break
        
        item = random.choice(available_items)
        try:
            if item.startswith(('http', 'https')):
                await interaction.user.send(item)
            else:
                if os.path.exists(item):
                    await interaction.user.send(file=discord.File(item))
                else:
                    await interaction.user.send(f"📁 Fichier non trouvé: {item}")
            
            USER_GENERATED[user_id].append(item)
            generated.append(item)
        except Exception as e:
            print(f"Erreur envoi: {e}")
            break
    
    save_data(USER_GENERATED, USER_GENERATED_FILE)
    USER_COOLDOWNS[user_id] = datetime.now() + timedelta(seconds=COOLDOWN_SECONDS)
    
    if generated:
        remaining = len(stock) - len(USER_GENERATED[user_id])
        await interaction.followup.send(
            f"✅ {len(generated)} élément(s) envoyé(s) en MP!\n"
            f"📊 Il te reste {remaining} éléments",
            ephemeral=True
        )

@bot.tree.command(name="soumettre", description="Soumettre du contenu au stock")
@app_commands.describe(lien="Lien ou contenu à soumettre")
async def soumettre_slash(interaction: discord.Interaction, lien: str):
    if not ADMIN_SETTINGS.get("bot_online", True):
        await interaction.response.send_message("❌ Le bot est actuellement en maintenance.", ephemeral=True)
        return
    
    success = await approval_system.send_approval_request(interaction.user, lien)
    
    if success:
        await interaction.response.send_message(
            "📨 Votre contenu a été soumis pour approbation! "
            "Vous recevrez un MP quand il sera approuvé ou refusé.",
            ephemeral=True
        )
    else:
        await interaction.response.send_message(
            "❌ Erreur lors de la soumission. Réessayez plus tard.",
            ephemeral=True
        )

@bot.tree.command(name="statut", description="Voir le statut du bot et du stock")
async def statut_slash(interaction: discord.Interaction):
    embed = discord.Embed(title="📊 Statut du Bot", color=0x00ff00)
    
    embed.add_field(name="🟢 Statut", value="En ligne" if ADMIN_SETTINGS.get("bot_online", True) else "En maintenance", inline=True)
    embed.add_field(name="📦 Stock total", value=len(stock), inline=True)
    embed.add_field(name="⏳ En attente", value=len(PENDING_APPROVAL), inline=True)
    
    if ADMIN_SETTINGS.get("last_restock"):
        last_time = datetime.fromisoformat(ADMIN_SETTINGS["last_restock"])
        embed.add_field(name="🕒 Dernier restock", value=last_time.strftime("%d/%m/%Y %H:%M"), inline=True)
    
    user_id = str(interaction.user.id)
    if user_id in USER_GENERATED:
        generated = len(USER_GENERATED[user_id])
        remaining = len(stock) - generated
        embed.add_field(name="🎯 Vos générations", value=f"{generated}/{len(stock)}", inline=True)
        embed.add_field(name="📭 Éléments restants", value=remaining, inline=True)
    
    await interaction.response.send_message(embed=embed, ephemeral=True)

# COMMANDES ADMIN
@bot.tree.command(name="admin_stock", description="[ADMIN] Gérer le stock")
@app_commands.describe(action="Action à effectuer", donnees="Données pour l'action")
async def admin_stock_slash(interaction: discord.Interaction, action: str, donnees: str = None):
    if interaction.user.id != RESTOCK_USER_ID:
        await interaction.response.send_message("❌ Non autorisé!", ephemeral=True)
        return
    
    global stock
    
    if action == "ajouter":
        new_items = [item.strip() for item in donnees.split(',') if item.strip()]
        stock.extend(new_items)
        stock = list(set(stock))
        save_data(stock, STOCK_FILE)
        
        ADMIN_SETTINGS["last_restock"] = datetime.now().isoformat()
        save_data(ADMIN_SETTINGS, ADMIN_SETTINGS_FILE)
        
        await interaction.response.send_message(f"✅ {len(new_items)} éléments ajoutés!", ephemeral=True)
    
    elif action == "vider":
        stock = []
        save_data(stock, STOCK_FILE)
        await interaction.response.send_message("🗑️ Stock vidé!", ephemeral=True)
    
    elif action == "stats":
        embed = discord.Embed(title="📊 Statistiques Admin", color=0xff0000)
        embed.add_field(name="📦 Stock", value=len(stock), inline=True)
        embed.add_field(name="👥 Utilisateurs", value=len(USER_GENERATED), inline=True)
        embed.add_field(name="⏳ En attente", value=len(PENDING_APPROVAL), inline=True)
        await interaction.response.send_message(embed=embed, ephemeral=True)

@bot.tree.command(name="admin_user", description="[ADMIN] Gérer un utilisateur")
@app_commands.describe(action="Action", utilisateur="Utilisateur", donnees="Données")
async def admin_user_slash(interaction: discord.Interaction, action: str, utilisateur: discord.User, donnees: str = None):
    if interaction.user.id != RESTOCK_USER_ID:
        await interaction.response.send_message("❌ Non autorisé!", ephemeral=True)
        return
    
    user_id = str(utilisateur.id)
    
    if action == "reset":
        if user_id in USER_GENERATED:
            del USER_GENERATED[user_id]
            save_data(USER_GENERATED, USER_GENERATED_FILE)
            await interaction.response.send_message(f"🔄 {utilisateur.mention} réinitialisé!", ephemeral=True)
        else:
            await interaction.response.send_message("❌ Utilisateur non trouvé!", ephemeral=True)
    
    elif action == "info":
        if user_id in USER_GENERATED:
            generated = len(USER_GENERATED[user_id])
            embed = discord.Embed(title=f"👤 Info {utilisateur.name}", color=0x00ff00)
            embed.add_field(name="Générations", value=generated, inline=True)
            embed.add_field(name="Restant", value=len(stock)-generated, inline=True)
            await interaction.response.send_message(embed=embed, ephemeral=True)
        else:
            await interaction.response.send_message("❌ Aucune donnée!", ephemeral=True)

@bot.tree.command(name="bot_control", description="[ADMIN] Contrôler le bot")
@app_commands.describe(action="Action")
async def bot_control_slash(interaction: discord.Interaction, action: str):
    if interaction.user.id != RESTOCK_USER_ID:
        await interaction.response.send_message("❌ Non autorisé!", ephemeral=True)
        return
    
    if action == "maintenance_on":
        ADMIN_SETTINGS["bot_online"] = False
        save_data(ADMIN_SETTINGS, ADMIN_SETTINGS_FILE)
        await interaction.response.send_message("🔧 Mode maintenance activé!", ephemeral=True)
    
    elif action == "maintenance_off":
        ADMIN_SETTINGS["bot_online"] = True
        save_data(ADMIN_SETTINGS, ADMIN_SETTINGS_FILE)
        await interaction.response.send_message("🟢 Bot en ligne!", ephemeral=True)

# Lancer le bot
if __name__ == "__main__":
    bot.run('MTQ0MDY4MTE2OTgyNDkxMTQ3MQ.GkWRo9.uUoEnch4zOFrYvLYl-eUPNuGHCdE8PtEFljJOo')